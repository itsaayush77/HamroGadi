package Controller;

import dao.UserDAO;
import model.User;

public class LoginController {

    private UserDAO userDAO;

    public LoginController() {
        this.userDAO = new UserDAO();
    }

    public User loginUser(String email, String password) {
        return userDAO.validateUser(email, password);
    }
}

