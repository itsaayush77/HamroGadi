package Controller;

import dao.userDAO;
import model.User;

public class RegisterController {

    private userDAO userDAO;

    public RegisterController() {
        this.userDAO = new userDAO();
    }

    public boolean registerUser(String name, String email, String password, String phone, String address, String role) {
        User user = new User(name, email, password, phone, address, role);
        return userDAO.registerUser(user);
    }
}