package Servlet;

import Controller.LoginController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.User;
import java.io.IOException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private LoginController loginController;

    public LoginServlet() {
        super();
        this.loginController = new LoginController();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String rememberMe = request.getParameter("rememberMe");

        User user = loginController.loginUser(email, password);

        if (user != null) {
            // Set user in session
            HttpSession session = request.getSession();
            session.setAttribute("user", user);

            // Handle "Remember Me" with cookies
            if ("on".equals(rememberMe)) {
                Cookie emailCookie = new Cookie("email", email);
                Cookie passwordCookie = new Cookie("password", password);
                emailCookie.setMaxAge(30 * 24 * 60 * 60); // 30 days
                passwordCookie.setMaxAge(30 * 24 * 60 * 60); // 30 days
                response.addCookie(emailCookie);
                response.addCookie(passwordCookie);
            }

            // Role-based redirection
            if ("Admin".equals(user.getRole())) {
                response.sendRedirect(request.getContextPath() + "/dashboard_admin.jsp");
            } else {
                response.sendRedirect(request.getContextPath() + "/dashboard_user.jsp");
            }
        } else {
            response.sendRedirect(request.getContextPath() + "/login.jsp?error=1");
        }
    }
}