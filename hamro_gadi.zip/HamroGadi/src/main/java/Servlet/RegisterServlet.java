package Servlet;

import Controller.RegisterController;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private RegisterController registerController;

    public RegisterServlet() {
        super();
        this.registerController = new RegisterController();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.getRequestDispatcher("/register.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String phone = request.getParameter("phone");
        String address = request.getParameter("address");
        String role = "User"; // Default role for registration; admins can be added manually in the database

        boolean success = registerController.registerUser(name, email, password, phone, address, role);

        if (success) {
            response.sendRedirect(request.getContextPath() + "/login.jsp?success=1");
        } else {
            response.sendRedirect(request.getContextPath() + "/register.jsp?error=1");
        }
    }
}